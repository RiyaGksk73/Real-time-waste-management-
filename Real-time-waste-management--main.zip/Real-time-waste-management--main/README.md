# Smart Waste Management System

A prototype mobile app with dashboards for **Citizens, Workers, and Admins** 
to track waste, earn rewards, and monitor city cleanliness.

## Features
- Citizen Dashboard: Green Points, complaints, eco-shop
- Worker Dashboard: Route tracking, work logs
- Admin Dashboard: Real-time monitoring, analytics

## Tech
- Designed with modern, eco-friendly UI
- Green-blue-white theme
